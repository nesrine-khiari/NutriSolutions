export declare enum GenderEnum {
    MALE = "homme",
    FEMALE = "femme"
}
export declare enum UserRoleEnum {
    CLIENT = "Client",
    NUTRITIONIST = "Nutritionist",
    ADMIN = "Admin"
}
export declare enum NutritionistStatusEnum {
    APPROVED = "Approuv\u00E9",
    REJECTED = "Rejet\u00E9",
    WAITING = "En attente"
}
