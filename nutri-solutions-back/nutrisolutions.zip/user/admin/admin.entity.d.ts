import { UserEntity } from '../user.entity';
export declare class AdminEntity extends UserEntity {
}
