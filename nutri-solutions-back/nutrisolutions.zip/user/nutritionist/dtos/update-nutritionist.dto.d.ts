import { CreateNutritionistDto } from './create-nutritionist.dto';
declare const UpdateNutritionistDto_base: import("@nestjs/mapped-types").MappedType<Partial<CreateNutritionistDto>>;
export declare class UpdateNutritionistDto extends UpdateNutritionistDto_base {
}
export {};
