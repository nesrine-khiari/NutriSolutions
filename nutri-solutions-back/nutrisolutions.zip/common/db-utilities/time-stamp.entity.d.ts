export declare class TimeStampEntity {
    createdAt: Date;
    updatedAt: Date;
    deleteddAt: Date;
    version: number;
}
