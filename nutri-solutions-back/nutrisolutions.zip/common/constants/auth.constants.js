"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.jwtConstants = void 0;
exports.jwtConstants = {
    secret: '89fd99a9b759e94c6c2e0332d304892e2eef786e578048e4c0ec74cb7a1f0078',
};
//# sourceMappingURL=auth.constants.js.map