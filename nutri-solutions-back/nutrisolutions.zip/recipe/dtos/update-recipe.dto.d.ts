import { CreateRecipeDto } from './create-recipe.dto';
declare const UpdateRecipeDto_base: import("@nestjs/mapped-types").MappedType<Partial<CreateRecipeDto>>;
export declare class UpdateRecipeDto extends UpdateRecipeDto_base {
}
export {};
