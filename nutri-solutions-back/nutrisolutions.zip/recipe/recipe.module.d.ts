export declare class RecipeModule {
}
