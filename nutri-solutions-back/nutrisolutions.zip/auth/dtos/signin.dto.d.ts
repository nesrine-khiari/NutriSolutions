export declare class SignInDto {
    email: string;
    password: string;
}
